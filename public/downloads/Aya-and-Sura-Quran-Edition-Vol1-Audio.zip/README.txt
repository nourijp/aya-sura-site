Aya & Sura — Quran Edition (Volume 1) audio
========================================

50 recordings of the words from Volume 1 of the Aya & Sura flashcards, pronounced
slowly by a native speaker.

Files are named with the card number printed at the bottom-left of each card (QE1-01 … QE1-50).

Keep in mind that the way an Arabic word is pronounced in isolation will vary from the
way it is pronounced in an ayah of the Holy Quran, because there are various rules about
how to connect the words together.

More: https://ayasura.com/qr/
Questions: support@ayasura.com
(c) Aya & Sura, LLC. For personal and family use.
